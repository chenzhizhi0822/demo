import json
import re
import ast


def construct_prompt(d):
    """
    构造用于大语言模型的提示词
    """
    system_prompt = """你是一个ARC抽象推理专家。请仔细观察训练示例中的输入输出变换规律，然后对测试输入应用相同的规则。

重要要求：
1. 只输出最终的二维数组，不要任何解释
2. 确保输出的格式是有效的Python列表
3. 仔细分析每个训练示例的变换模式"""

    examples_text = ""
    for i, example in enumerate(d['train']):
        examples_text += f"训练示例 {i + 1}:\n"
        examples_text += f"输入: {example['input']}\n"
        examples_text += f"输出: {example['output']}\n\n"

    test_input = d['test'][0]['input']

    user_content = f"""{examples_text}
基于以上训练示例中展示的变换规律，请对以下测试输入进行变换：

测试输入: {test_input}

请只输出变换后的二维数组："""

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content}
    ]


def parse_output(text):
    """
    解析大语言模型的输出文本，提取预测的网格
    """
    # 清理文本，移除可能的标记和多余空格
    cleaned_text = text.strip()

    # 尝试直接解析为Python列表
    try:
        result = ast.literal_eval(cleaned_text)
        if isinstance(result, list) and all(isinstance(row, list) for row in result):
            return result
    except:
        pass

    # 使用正则表达式匹配二维数组模式
    patterns = [
        r'\[\[.*?\]\]',  # 匹配 [[...]]
        r'\[[^\[\]]*\]'  # 匹配单层数组
    ]

    for pattern in patterns:
        matches = re.findall(pattern, cleaned_text, re.DOTALL)
        for match in matches:
            try:
                # 清理匹配的文本
                clean_match = match.replace('\n', '').replace(' ', '')
                result = ast.literal_eval(clean_match)
                if isinstance(result, list):
                    # 如果是二维数组
                    if all(isinstance(row, list) for row in result):
                        return result
                    # 如果是一维数组，尝试重新组织
                    elif all(isinstance(item, (int, float)) for item in result):
                        # 假设是正方形网格
                        size = int(len(result) ** 0.5)
                        if size * size == len(result):
                            return [result[i * size:(i + 1) * size] for i in range(size)]
            except:
                continue

    # 如果所有方法都失败，返回空数组
    return []